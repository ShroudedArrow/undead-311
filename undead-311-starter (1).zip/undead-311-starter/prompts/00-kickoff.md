# 00 — Kickoff session (paste into Kiro chat, IDE or CLI)

Read docs/PROJECT.md and every file in .kiro/steering/. Then:
1. Confirm the MCP servers in .kiro/settings/mcp.json are connected (context7, duckdb, ckan, playwright). Report any that fail.
2. Use the ckan MCP server (or, if it isn't available, the CKAN API directly from Python: `https://data.boston.gov/api/3/action/package_show?id=311-service-requests`) against https://data.boston.gov to find the "311 Service Requests" dataset and list its resources (year, format, URL, last modified). Write the list to data/README.md.
3. Write a script `pipeline/scripts/download.py` that downloads the 2015-present CSVs into `$DATA_DIR/raw/` (outside the repo; skip files already present; record file hashes and download date in `data/SNAPSHOT.md`), then run it.
4. Load the files into `$DATA_DIR/processed/undead311.duckdb` (one raw table per system format). Use the duckdb MCP server (or, in a cloud sandbox, DuckDB from Python: `uv run --with duckdb python`) to inspect real columns, value distributions of `type`, `closure_reason`, `case_status`, and coordinates. Compare legacy vs. newer-system records (new-system names include `open_date`, `close_date`, `service_name`, `assigned_department`). **Go/no-go check:** does the new-system data (Oct 2025 onward) include coordinates (or addresses we can match to SAM) and closure text? Report clearly. If either is missing, stop and write the finding to docs/DECISIONS.md; the validation plan and planned-follow-up rule depend on them.
5. List all distinct case types and propose the in-scope list for zombie-definition.md (public right-of-way only; exclude types about people and private residences). Do not change the definition's rules.
6. Update .kiro/steering/data-dictionary.md with the VERIFIED fields, differences between formats, a first draft of type families, and the 30 most common closure-text templates.
7. Create data/sample/ (about 20,000 rows across several years and types, including known re-report patterns) for tests.
8. Create the Makefile, `.python-version`, `.nvmrc`, and lock files with the targets listed in structure.md (stubs are fine where code doesn't exist yet).
9. Append a line to docs/KIRO_LOG.md.
Do not start feature work yet.
